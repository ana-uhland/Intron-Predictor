To run the program use a small sequence in a fasta file and place both the .py file and you fasta file in the same directory
to run the progrma input 'python IntronPred.py' the program will ask for specific fasta file. The file seq.fasta is included to run the program with.

The program utilizes MatLab please have it installed before running. 

The class FastAreader is from class and is used with permission from David Bernick.