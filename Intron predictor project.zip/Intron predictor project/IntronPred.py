import sys
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

'''class fast Areader from class not my work given by Professor David Bernick'''
class FastAreader:
    def __init__(self, fname=''):
        '''constructor: saves attribute fname'''
        self.fname = fname

    def doOpen(self):
        if self.fname == '':
            return sys.stdin
        else:
            return open(self.fname)

    def readFasta(self):
        header = ''
        sequence = ''
        with self.doOpen() as fileH:
            header = ''
            sequence = ''
            # skip to the first fasta header
            line = fileH.readline()
            while not line.startswith('>'):
                if not line:  # we are at EOF
                    return header, sequence
                line = fileH.readline()
            header = line[1:].rstrip()
            for line in fileH:
                if line.startswith('>'):
                    yield header, sequence
                    header = line[1:].rstrip()
                    sequence = ''
                else:
                    sequence += ''.join(line.rstrip().split()).upper()
            yield header, sequence






class IntronPredictor:
    #Intron end and start probality tabels gerenated from the weight diagram
    intron_end_ID = {
        1: {'A': 0.09, 'G': 0.09, 'C': 0.27, 'T': 0.54},
        2: {'A': 0.08, 'G': 0.08, 'C': 0.27, 'T': 0.57},
        3: {'A': 0.234, 'G': 0.23, 'C': 0.26, 'T': 0.27},
        4: {'A': 0.11, 'G': 0, 'C': 0.62, 'T': 0.27},
        5: {'A': 1, 'G': 0, 'C': 0, 'T': 0},
        6: {'A': 0, 'G': 1, 'C': 0, 'T': 0}
    }

    intron_start_ID = {
        1: {'A': 0, 'G': 1, 'C': 0, 'T': 0},
        2: {'A': 0, 'G': 0, 'C': 0, 'T': 1},
        3: {'A': 0.567, 'G': 0.27, 'C': 0.108, 'T': 0.054},
        4: {'A': 0.67567, 'G': 0.108, 'C': 0.108, 'T': 0.108},
        5: {'A': 0.06756, 'G': 0.7297, 'C': 0.06756, 'T': 0.06756},
        6: {'A': 0.141891, 'G': 0.141891, 'C': 0.141891, 'T': 0.4324}
    }

    def __init__(self, sequence):
        #making the sequence all uppercase
        self.sequence = sequence.upper()

    def find_start(self): # finding starts by seaching for GT then grabbing the next 4 nucliodtides after
        start_sites = set()
        for i in range(len(self.sequence) - 5):
            if self.sequence[i:i + 2] == 'GT':
                if i + 6 < len(self.sequence):
                    start_sites.add((i, self.sequence[i:i + 6]))
        return start_sites

    def find_end(self): # finding ends by finding AG first then grabbing the 4 nucliotides in front of it
        end_sites = set()
        for i in range(len(self.sequence) - 5):
            if self.sequence[i + 4:i + 6] == 'AG':
                if i >= 0:
                    end_sites.add((i, self.sequence[i:i + 6]))
        return end_sites

    def calculate_likelihood_of_end(self, end_sequence): #using the 6 nucliotide sequence gerated compaire it to the dictoray
        likelihood = 1.0
        for i in range(6):
            base = end_sequence[i]
            likelihood *= self.intron_end_ID[i + 1][base]
        return likelihood

    def likelihood_of_all_ends(self, end_sites): #creating the dictoray of all the end's likelihood value ID and posisiton
        # Filter out sites with likelihood 0
        filtered_end_sites = [(index, sequence) for index, sequence in end_sites if
                              all(self.intron_end_ID[i + 1][base] != 0 for i, base in enumerate(sequence))]

        likelihoods = {}
        for site in filtered_end_sites:
            end_sequence = site[1]
            likelihood = self.calculate_likelihood_of_end(end_sequence)
            likelihoods[site] = likelihood
        return likelihoods

    def calculate_likelihood_of_start(self, start_sequence):#using the 6 nucliotide sequence gerated compaire it to the dictoray
        likelihood = 1.0
        for i in range(6):
            base = start_sequence[i]
            likelihood *= self.intron_start_ID[i + 1][base]
        return likelihood

    def likelihood_of_all_starts(self, start_sites): #creating a dictonary with likelyhood value, ID and positon
        # Filter out sites with likelihood 0
        filtered_start_sites = [(index, sequence) for index, sequence in start_sites if
                                all(self.intron_start_ID[i + 1][base] != 0 for i, base in enumerate(sequence))]

        likelihoods = {}
        for site in filtered_start_sites:
            start_sequence = site[1]
            likelihood = self.calculate_likelihood_of_start(start_sequence)
            likelihoods[site] = likelihood
        return likelihoods

    def print_likelihoods(self): # this pairs our starts and ends to each other and sorts the introns by user prefrences
        sequence = self.sequence
        start_sites = self.find_start()
        end_sites = self.find_end()

        # Filter out sites with likelihood 0
        filtered_start_sites = [(index, sequence) for index, sequence in start_sites if all(self.intron_start_ID[i + 1][base] != 0 for i, base in enumerate(sequence))]
        filtered_end_sites = [(index, sequence) for index, sequence in end_sites if all(self.intron_end_ID[i + 1][base] != 0 for i, base in enumerate(sequence))]

        combinations = []
        for start_site in filtered_start_sites:
            start_index, start_sequence = start_site
            for end_site in filtered_end_sites:
                end_index, end_sequence = end_site
                if start_index < end_index:
                    start_likelihood = self.calculate_likelihood_of_start(start_sequence)
                    end_likelihood = self.calculate_likelihood_of_end(end_sequence)
                    combined_likelihood = start_likelihood + end_likelihood
                    intron_size = end_index - start_index - 1
                    combinations.append((start_index, start_sequence, end_index, end_sequence, combined_likelihood, intron_size))

        # Ask user for sorting preference
        sort_by_size = input("Sort introns by size? (y/n): ")
        if sort_by_size.lower() == 'y':
            try:
                input_size = int(input("Enter the desired intron size: "))
            except ValueError:
                print("Invalid input. Introns will be sorted by likelihood.")
                sorted_combinations = sorted(combinations, key=lambda x: (abs(x[5] - input_size), x[4]), reverse=True)
            else:
                sorted_combinations = sorted(combinations, key=lambda x: (abs(x[5] - input_size) == 0, abs(x[5] - input_size), x[4]))

        else:
            sorted_combinations = sorted(combinations, key=lambda x: x[4], reverse=True)

        return sorted_combinations

    def filter_low_likelihood_introns(self, sorted_combinations): # in my tests I didnt find any valid introns with combine value lower then this, can be removed
        return [comb for comb in sorted_combinations if comb[4] >= 0.005]

    def visualize_likelihoods(self, sorted_combinations): #using mat lab to create our visual of our data
        if not sorted_combinations:
            print("No intron predictions to visualize.")
            return

        # Filter introns with low likelihood
        sorted_combinations = self.filter_low_likelihood_introns(sorted_combinations)

        if not sorted_combinations:
            print("No intron predictions to visualize after filtering.")
            return

        # Prepare data for plotting
        sequence_length = len(self.sequence)
        intron_segments = []
        intron_labels = []
        y_ticks = []
        y_tick_labels = []
        likelihoods = []

        # Collect intron data
        for i, combination in enumerate(sorted_combinations):
            start_index, start_seq, end_index, end_seq, likelihood, _ = combination
            intron_size = end_index - start_index - 1
            intron_segments.append((start_index, end_index))
            intron_labels.append(f"{start_seq[:6]}...{end_seq[-6:]}")
            y_ticks.append(i)
            y_tick_labels.append(f"Intron {i + 1}: {intron_size}")
            likelihoods.append(likelihood)

        # Define a custom colormap
        colors = [(0, 'blue'), (0.5, 'purple'), (1, 'pink')]
        cmap = LinearSegmentedColormap.from_list('custom', colors)

        # Map likelihoods to colors using a colormap
        norm = plt.Normalize(min(likelihoods), max(likelihoods))
        colors = cmap(norm(likelihoods))

        # Create the plot
        fig, ax = plt.subplots(figsize=(15, 6))
        for i, (start, end) in enumerate(intron_segments):
            plt.plot([start, end], [i, i], color=colors[i], linewidth=2)
            plt.text(start, i, f"{intron_labels[i][:6]}", va='center', ha='right')  # Annotate the start of the bar
            plt.text(end, i, f"{intron_labels[i][-6:]}", va='center', ha='left')  # Annotate the end of the bar

        # Add color scale as a colorbar on the side
        sm = plt.cm.ScalarMappable(cmap=cmap, norm=norm)
        sm.set_array([])
        cbar = plt.colorbar(sm, ax=ax)
        cbar.set_label('Likelihood')

        plt.title('Intron Predictions with Likelihood Visualization')
        plt.xlabel('Sequence Position')
        plt.ylabel('Intron Number and Size')
        plt.xticks(range(0, sequence_length + 1, 100))
        plt.yticks(y_ticks, y_tick_labels)
        plt.grid(True)
        plt.show()

def main():
    # Ask the user for the filename
    fileName = input("Enter the filename: ")
    #open the file and get the sequence
    fasta_reader = FastAreader(fileName)
    for header, sequence in fasta_reader.readFasta():
        print(f"Header: {header}")
        predictor = IntronPredictor(sequence)
        sorted_combinations = predictor.print_likelihoods()
        predictor.visualize_likelihoods(sorted_combinations)

if __name__ == "__main__":
    main()
